/*
  Author: Jared Wu
  Description: The USB probe/disconnect device driver for USB device driver training
*/

#include <sound/driver.h>
#include <linux/bitops.h>
#include <linux/init.h>
#include <linux/list.h>
#include <linux/slab.h>
#include <linux/string.h>
#include <linux/usb.h>
#include <linux/moduleparam.h>
#include <sound/core.h>

MODULE_AUTHOR("jared Wu <jared_wu@msa.hinet.net>");
MODULE_DESCRIPTION("USB Audio");
MODULE_LICENSE("GPL");
MODULE_SUPPORTED_DEVICE("{{Generic,USB Audio}}");

static struct usb_device_id my_usb_ids [] = {
#if 1 // Match the Vendor/Product ID
    { USB_DEVICE(0x0c76, 0x1605) },
#else
    { .match_flags = (USB_DEVICE_ID_MATCH_INT_CLASS | USB_DEVICE_ID_MATCH_INT_SUBCLASS),
      .bInterfaceClass = USB_CLASS_AUDIO,
      .bInterfaceSubClass = USB_SUBCLASS_AUDIO_CONTROL },
#endif
    { }						/* Terminating entry */
};

MODULE_DEVICE_TABLE (usb, my_usb_ids);

static int my_usb_probe(struct usb_interface *intf,
			   const struct usb_device_id *id)
{
	printk("my_usb_probe:%x:%x\n",id->idVendor, id->idProduct );

	return 0;
}

static void my_usb_disconnect(struct usb_interface *intf)
{
	printk("my_usb_disconnect:\n");
}

static struct usb_driver my_usb_driver = {
	.owner =	THIS_MODULE,
	.name =		"my-usb-audio",
	.probe =	my_usb_probe,
	.disconnect =	my_usb_disconnect,
	.id_table =	my_usb_ids,
};

static int __init my_usb_init(void)
{
	usb_register(&my_usb_driver);
	return 0;
}


static void __exit my_usb_cleanup(void)
{
	usb_deregister(&my_usb_driver);
}

module_init(my_usb_init);
module_exit(my_usb_cleanup);
