#include <stdio.h>

int main() {
  printf("aaaaa\n");
#if __TEST__
  printf("bbbb\n");
#endif
}
