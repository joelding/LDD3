#include <linux/kernel.h>    // need for kernel alert
#include <linux/module.h>
#include <linux/init.h>         // need for __init and __exit

static int __init hello_2_init(void) 
{ 
#ifdef __TEST__
printk("<1>Test\n");
#endif
printk("<1>Hello! world\n");
return 0;
}

static void __exit hello_2_exit(void) 
{ 
printk("<1>Bye Bye\n"); 
}

module_init(hello_2_init);
module_exit(hello_2_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Jared");
MODULE_DESCRIPTION("Say Hello!");
MODULE_SUPPORTED_DEVICE("no");
