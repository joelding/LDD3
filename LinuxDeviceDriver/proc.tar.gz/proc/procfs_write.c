#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/init.h>         // need for __init and __exit
#include <linux/proc_fs.h>
#include <asm/uaccess.h> /* for put_user */
#define PROCFS_NAME "proc_write"

static struct proc_dir_entry *proc;
static int write_value=0; // flag, 1:start the garbage collection, 0:stop the gargabe collection

static int proc_write(struct file *file, const char *buffer, unsigned long count, void *data) {
	char tmpbuf[4];
	int len;
	
	len = ( count > 4 ) ? 4 : count;
	
	if(copy_from_user( tmpbuf, buffer, len)) {
		return -EFAULT;
	}
	tmpbuf[len]='\0';

	sscanf(tmpbuf, "%d", &write_value);
	
	if ( write_value ) // wake up the sleeping garbage collection thread
		printk("You Input nonzero value:%d\n", write_value);
	else
		printk("You Input zero value:%d\n", write_value);
	
	return len;

}

static int __init proc_write_init(void) 
{ 

    proc = create_proc_entry(PROCFS_NAME, 0644, NULL);
    proc->write_proc = proc_write;

    printk("<1>Trying to create /proc/%s:\n", PROCFS_NAME);
    if (proc == NULL) {
    	remove_proc_entry(PROCFS_NAME, &proc_root);
    	printk("<1>Error: Could not initialize /proc/%s\n", PROCFS_NAME);
	return -ENOMEM;
    }
    printk("<1>Success!\n");
    return 0;
}

static void __exit proc_write_exit(void) 
{ 
    remove_proc_entry(PROCFS_NAME, NULL);
}

module_init(proc_write_init);
module_exit(proc_write_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Jared");
MODULE_DESCRIPTION("Say Hello!");
MODULE_SUPPORTED_DEVICE("no");
