#include <linux/kernel.h>    // need for kernel alert
#include <linux/module.h>
#include <linux/init.h>      // need for __init and __exit
#include <linux/kmod.h>      // need for request_module
#include "slave.h"

static int __init master_init(void) 
{ int r[2];
  slave_test();
  //r[0]=request_module("slave");
  //r[1]=request_module("nonexistent");
  printk("<1>master loading results are %i, %i\n",r[0],r[1]);
  return 0;
}

static void __exit master_exit(void) 
{ 
}

module_init(master_init);
module_exit(master_exit);

MODULE_LICENSE("GPL");
