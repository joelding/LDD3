#include <linux/kernel.h>    // need for kernel alert
#include <linux/module.h>
#include <linux/init.h>         // need for __init and __exit

static int __init slave_init(void) 
{ 
printk("<1>slave loading\n");
return 0;
}

static void __exit slave_exit(void) 
{ 
}

module_init(slave_init);
module_exit(slave_exit);

MODULE_LICENSE("GPL");
