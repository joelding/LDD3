#include <linux/kernel.h>    // need for kernel alert
#include <linux/module.h>
#include <linux/init.h>         // need for __init and __exit
#include <linux/sched.h> // for send_sig()

static int user_pid = 20;
MODULE_PARM(user_pid, "i");
MODULE_PARM_DESC(user_pid, "The process id which will receive the USR1 signal");

static int __init signalmod_init(void) 
{
	struct task_struct *p;
	p=find_task_by_pid(user_pid);
	send_sig( SIGUSR1, p, 0);
	send_sig( SIGUSR1, p, 0);	
	return 0;
}

static void __exit signalmod_exit(void) 
{ 
}

module_init(signalmod_init);
module_exit(signalmod_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Jared");
MODULE_DESCRIPTION("signal to user process!");
MODULE_SUPPORTED_DEVICE("no");
