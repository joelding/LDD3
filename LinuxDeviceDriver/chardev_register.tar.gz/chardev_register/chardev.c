#include <linux/version.h>
#include <linux/kernel.h>    // need for kernel alert
#include <linux/module.h>
#include <linux/init.h>         // need for __init and __exit
#include <asm/uaccess.h>     // for ssize_t
#include <linux/fs.h>          // for struct file_operations
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,0)
#include <linux/cdev.h>
static struct cdev mycdev;
#endif

static int major=230;

int dev_open (struct inode *inode, struct file *fs) {
  printk("dev_open\n");  

  return 0;
}

int dev_release (struct inode *inode, struct file *fs) {
  printk("dev_release\n");  

  return 0;
}

ssize_t dev_read (struct file *fs, char __user *buffer, size_t size, loff_t *lo) {
  printk("dev_read\n");

  return 0;
}

ssize_t dev_write (struct file *fs, const char __user *buffer, size_t size, loff_t *lo) {
  printk("dev_write\n");

  return -1;
}

static struct file_operations fops = {
    .read = dev_read,
    .write = dev_write,
    .open = dev_open,
    .release = dev_release
};

static int __init hello_2_init(void) 
{ 
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,0)
    dev_t devno=0;

    if(major) {
        if ( register_chrdev_region(MKDEV(major,0), 1, "char_reg") < 0 ) {
            printk ("register_chrdev_region() fail\n");
            return -1;
        }
    }
    else {
        if (alloc_chrdev_region(&devno, 0, 1, "char_reg") < 0) {
           printk ("alloc_chrdev_region() fail\n");
           return -1;
        }
        major=MAJOR(devno);
    }
    cdev_init(&mycdev, &fops);
    mycdev.owner=THIS_MODULE;
    if(cdev_add(&mycdev, MKDEV(major,0), 1)) {
        printk ("Error adding cdev\n");
    }
#else
    major=register_chrdev(0, "char_reg", &fops);
    if (major < 0) {
        printk ("Registering the character device failed with %d\n", major);
        return -1;
    }
#endif
    printk("I was assigned major number %d.\n", major);
    printk("Create a dev file: mknod /dev/chardev c %d 0\n", major);
    printk("Try to cat and echo to the device file\n");
    printk("Remove it when done.\n");
 
    return 0;
}

static void __exit hello_2_exit(void) 
{ 
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,0)
    cdev_del(&mycdev);
    unregister_chrdev_region(MKDEV(major, 0), 1);
#else
    unregister_chrdev(major, "char_reg");
#endif
}

module_init(hello_2_init);
module_exit(hello_2_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Jared");
MODULE_DESCRIPTION("Register Character Driver!");
MODULE_SUPPORTED_DEVICE("none");
