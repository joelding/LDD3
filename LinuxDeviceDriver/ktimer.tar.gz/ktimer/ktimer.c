#include <linux/kernel.h>    // need for kernel alert
#include <linux/module.h>
#include <linux/init.h>         // need for __init and __exit
#include <linux/proc_fs.h>
#include <linux/timer.h>

#include <linux/interrupt.h>
#define MAX_TIMEOUT_COUNT 20

// To do: Declare a kernel timer
static struct timer_list timer1;

static struct timeval current_time[MAX_TIMEOUT_COUNT];
static int timeout_count;
static struct proc_dir_entry *ktimer_proc;

ssize_t ktimer_proc_fn (char *buffer, char **buffer_location, off_t off, int buffer_length, int *eof, void *data) {
  int len = 0, i;
  
  if(off > 0) {
    return len;
  }

  // To do: return the time recorders from /proc/ktimer
  for( i=0; i<MAX_TIMEOUT_COUNT; i++) {
  	len += sprintf(buffer+len,"[%d].tv_sec:%lu, [%d].tv_usec:%lu\n", i, current_time[i].tv_sec, i, current_time[i].tv_usec);
  }

  return len;
}

static void timer1_expire(unsigned long data)
{
  // If you want to do something periodically, add your code here
  do_gettimeofday(&current_time[timeout_count]);
  timeout_count++;
  
  if ( in_interrupt() )
    printk("in interrupt context\n");
  else
    printk("in process context\n");

  if ( in_irq() )
    printk("in interrupt handler\n");
  else
    printk("not in interrupt handler\n");
	 
  if( timeout_count < MAX_TIMEOUT_COUNT ) {
    // To do: add timer again
    timer1.function=timer1_expire;
    timer1.expires = jiffies + 1 * (HZ / 1000);
    add_timer(&timer1);

  }
}

static int __init ktimer_init(void) 
{
  printk("HZ:%d\n",HZ);
  ktimer_proc=create_proc_read_entry("ktimer", 0644, NULL, ktimer_proc_fn, NULL);
  // To do: initialize the kernel timer 
  init_timer(&timer1);

  // To do: set the kernel expire time and callback function
  timer1.function=timer1_expire;
  timer1.expires = jiffies + 1 * HZ / 1000;

  // To do: add timer
  add_timer(&timer1);
  return 0;
}

static void __exit ktimer_exit(void) 
{
  remove_proc_entry("ktimer",NULL);

  // To do: delete the pending timer
  if( timer_pending(&timer1) )
    del_timer(&timer1);
}

module_init(ktimer_init);
module_exit(ktimer_exit);
MODULE_LICENSE("GPL");
MODULE_AUTHOR("jiunnder2000@yahoo.com.tw");
MODULE_DESCRIPTION("kernel timer example");
