#include <linux/config.h>
#include <linux/kernel.h>
#include <linux/errno.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/moduleparam.h>
#include <linux/spinlock.h>
#include <asm/uaccess.h>
#include <linux/usb.h>

#define DRIVER_DESC "Prolific PL2303 probe driver"

static struct usb_device_id id_table [] = {
	{ USB_DEVICE(0x067b, 0x2303) },
	{ }	/* Terminating entry */
};

MODULE_DEVICE_TABLE (usb, id_table);

static int my_pl2303_probe(struct usb_interface *intf,
			   const struct usb_device_id *id)
{
	printk("<1>my_usb_probe:%x:%x\n",id->idVendor, id->idProduct );

	return 0;
}

static void my_pl2303_disconnect(struct usb_interface *intf)
{
	printk("<1>my_usb_disconnect:\n");
}

static struct usb_driver pl2303_driver = {
	.owner =	THIS_MODULE,
	.name =		"my_pl2303",
	.probe =	my_pl2303_probe,
	.disconnect =	my_pl2303_disconnect,
	.id_table =	id_table,
};

static int __init pl2303_init (void)
{
	int retval;
	retval = usb_register(&pl2303_driver);
	if (retval) {
		printk("<1>%s usb_register() fail\n", DRIVER_DESC);
		return retval;
	}
	printk("<1>usb_register %s\n", DRIVER_DESC);
	return 0;
}


static void __exit pl2303_exit (void)
{
	printk("<1>usb_unregister %s\n", DRIVER_DESC);
	usb_deregister (&pl2303_driver);
}


module_init(pl2303_init);
module_exit(pl2303_exit);

MODULE_DESCRIPTION(DRIVER_DESC);
MODULE_LICENSE("GPL");

