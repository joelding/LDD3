
#include <linux/kernel.h>
#include <linux/module.h>
#include <asm/uaccess.h> /* for put_user */
#include <linux/version.h>

#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,0)
#include <linux/workqueue.h>
#else
#include <linux/tqueue.h>
#endif

#include <linux/interrupt.h>

#if 0
#include <linux/sched.h>
DECLARE_WAIT_QUEUE_HEAD(wq);
int bSleep=0;
#endif

struct my_data{
	int len;
	char *buf;
	unsigned long jiffies;
} mytq_data;

void mytq_fun (void *ptr)
{
	struct my_data *data = (struct my_data *) ptr;
	
	if ( in_interrupt() )
		printk("in interrupt context\n");
	else
		printk("in process context\n");

	if ( in_irq() )
		printk("in interrupt handler\n");
	else
		printk("not in interrupt handler\n");
#if 0
	bSleep=0;
	wait_event_interruptible(wq, bSleep);
#endif
	printk("I am in mytq_fun, jiffies = %ld, len = %d\n", jiffies, data->len);
	printk("The message is: %s \n", data->buf);
}

#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,0)
static DECLARE_WORK(mytq_task, mytq_fun, &mytq_data);
#else
struct tq_struct mytq_task;
#endif

int init_module(void)
{
	int len = 100;
	char *buf = "Hello from mytq_fun";
	
	mytq_data.len = len ;
	mytq_data.buf = buf ;
	mytq_data.jiffies = jiffies ;
	
	printk ("queued task at jiffies = %ld\n", jiffies );
#if LINUX_VERSION_CODE > KERNEL_VERSION(2,6,0)
	schedule_work(&mytq_task);
#else
	mytq_task.data = (void *) &mytq_data ;
	mytq_task.routine = mytq_fun ;

	//queue_task ( &mytq_task, &tq_scheduler ) ;
	//queue_task ( &mytq_task, &tq_timer ) ;
	queue_task ( &mytq_task, &tq_immediate ) ;
	mark_bh ( IMMEDIATE_BH );
#endif	

  return 0;
}

void cleanup_module(void)
{
#if 0
	bSleep=1;
	wake_up_interruptible(&wq);
#endif
	printk ("I cleaned up, jiffies = %ld\n", jiffies );
}

