#include <linux/kernel.h>
#include <linux/module.h>
#include <asm/uaccess.h> /* for put_user */
#include <linux/interrupt.h>

#if 0
#include <linux/sched.h>
DECLARE_WAIT_QUEUE_HEAD(wq);
int bSleep=0;
#endif

#define DEVICE_NAME "taskQ" 


void mytl_fun (unsigned long t)
{
	if ( in_interrupt() )
		printk("in interrupt context\n");
	else
		printk("in process context\n");

	if ( in_irq() )
		printk("in interrupt handler\n");
	else
		printk("not in interrupt handler\n");

#if 0
	bSleep=0;
	wait_event_interruptible(wq, bSleep);
#endif
	printk("I am in mytq_fun, jiffies = %ld\n", jiffies);
}

DECLARE_TASKLET(my_tasklet, mytl_fun, 0);

int init_module(void)
{
	printk ("queued task at jiffies = %ld\n", jiffies );
	tasklet_schedule(&my_tasklet);	

  return 0;
}

void cleanup_module(void)
{
#if 0 
	bSleep=1;
	wake_up_interruptible(&wq);
#endif
	printk ("I cleaned up, jiffies = %ld\n", jiffies );
}

