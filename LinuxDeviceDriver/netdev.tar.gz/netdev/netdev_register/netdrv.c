#include<linux/module.h>
#include<linux/config.h>
#include<linux/netdevice.h>

int netdrv_open(struct net_device *dev)
{
	printk("netdrv_open called\n");
	netif_start_queue(dev);
	return 0;
}

int netdrv_release(struct net_device *dev)
{
	printk("netdrv_release called\n");
	netif_stop_queue(dev);
	return 0;
}

static int netdrv_xmit(struct sk_buff *skb, struct net_device *dev)
{
	printk("dummy xmit function called....\n");
	dev_kfree_skb(skb);
	return 0;
}

int netdrv_init(struct net_device *dev)
{
	dev->open=netdrv_open;
	dev->stop=netdrv_release;
	dev->hard_start_xmit=netdrv_xmit;
	printk("netdrv device initialized\n");
	return 0;
}

struct net_device netdrv={init: netdrv_init};

int netdrv_init_module(void)
{
	int result;
	
	strcpy(netdrv.name,"netdrv");
	if((result=register_netdev(&netdrv))){
		printk("netdrv:Error%d initializing card netdrvcard",result);
		return result;
	}
	return 0;
}

void netdrv_cleanup(void)
{
	printk("<0>Cleaning Up the Module\n");
	unregister_netdev(&netdrv);
}

module_init(netdrv_init_module);
module_exit(netdrv_cleanup);
